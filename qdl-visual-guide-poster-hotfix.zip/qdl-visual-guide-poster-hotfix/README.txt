QDL Visual Guide poster-image hotfix

Upload these files to the website root and replace the existing versions.
The poster frames now use PNG rather than SVG to avoid host MIME or browser rendering issues.
